/* -*- C++ -*- */
/*************************************************************************
 * Copyright(c) 1995~2005  Masaharu Goto (root-cint@cern.ch)
 *
 * For the licensing terms see the file COPYING
 *
 ************************************************************************/


#ifdef __CINT__
#pragma link off class G__MethodInfo;
#pragma link off class G__DataMemberInfo;
#pragma link off class G__DataMemberInfo::error_code;
#pragma link off class G__FriendInfo;
#pragma link off class G__ClassInfo;
#pragma link off class G__ClassInfo::MatchMode;
#pragma link off class G__BaseClassInfoInfo;
#pragma link off class G__BaseClassInfoInfo;
#pragma link off class G__TypeInfo;
#pragma link off class G__MethodArgInfo;
#pragma link off class G__CallFunc;
#pragma link off class G__TokenInfo;
#pragma link off class G__SourceFileInfo;
#pragma link off class G__IncludePathInfo;

#pragma link off function operator==(map<string,string,less<string>,allocator<pair<const string,string> > >::iterator&,map<string,string,less<string>,allocator<pair<const string,string> > >::iterator&);
#pragma link off function operator!=(map<string,string,less<string>,allocator<pair<const string,string> > >::iterator&,map<string,string,less<string>,allocator<pair<const string,string> > >::iterator&);

#endif


