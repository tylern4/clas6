lib/pthread/README.txt

POSIX Thread library

 *** This directory is under construction ***
